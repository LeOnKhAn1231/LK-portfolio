
// MIX IT UP CONTENT
var mixer = mixitup('.work-grid');

//js for ham-menu
function openMenu(){
    document.getElementById('menu-container').style.width = "100%";
}
function closeMenu(){
    document.getElementById('menu-container').style.width = "0";
}
new WOW().init();